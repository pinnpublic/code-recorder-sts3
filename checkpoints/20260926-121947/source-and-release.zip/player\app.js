'use strict';
const $ = id => document.getElementById(id);
const labels = { edit: '코드 수정', activate: '파일 전환', transition: '파일 전환 안내', create: '파일 생성', delete: '파일 삭제', move: '파일 이동', end: '녹화 종료' };
const EDIT_INTERVAL_MS = 100;
const transitionDurationMs = () => Number($('transitionDuration').value) * 1000;
function updateOptionAvailability() {
  const active = !studyMode && $('follow').checked;
  $('waitForContinue').disabled = !active;
  $('continueDelay').disabled = !active || !$('waitForContinue').checked;
  $('transitionDuration').disabled = !active || $('waitForContinue').checked;
  for (const id of ['waitForContinue', 'continueDelay', 'transitionDuration']) {
    const control = $(id);
    control.parentElement?.classList.toggle('option-disabled', control.disabled);
  }
}
let lesson, replay, playing = false, lastFrame = 0, budget = 0, selected = null, renderKey = '', loadGeneration = 0;
let resumeAt = 0;
let steps = [], playbackEnds = [], stepIndex = 0, studyMode = false, transition = null;
let visited = new Set(), folders = new Map();
let timeUnits = [], timeSwitches = [];
function buildTimeIndex() {
  timeUnits = new Array(lesson.events.length + 1).fill(0);
  timeSwitches = new Array(lesson.events.length + 1).fill(0);
  const state = new CodeReplay.Replay(lesson);
  let units = 0, switches = 0;
  for (let index = 0; index < lesson.events.length;) {
    const event = lesson.events[index], end = playbackEnds[index];
    for (let cursor = index; cursor < end; cursor++) {
      timeUnits[cursor] = units; timeSwitches[cursor] = switches;
    }
    if (event.type !== 'end' && state.active && event.fileId !== state.active) switches++;
    units++; state.seekEvent(end);
    timeUnits[end] = units; timeSwitches[end] = switches; index = end;
  }
}
function renderTimes() {
  if (!replay) return;
  const interval = EDIT_INTERVAL_MS / Number($('speed').value);
  const delay = !$('follow').checked ? 0 : $('waitForContinue').checked
    ? Number($('continueDelay').value) * 1000 : transitionDurationMs();
  const durationAt = cursor => timeUnits[cursor] * interval + timeSwitches[cursor] * delay;
  const elapsed = durationAt(replay.cursor), remaining = durationAt(lesson.events.length) - elapsed;
  const format = seconds => {
    const minutes = Math.floor(seconds / 60), rest = seconds % 60;
    return String(minutes).padStart(2, '0') + ':' + String(rest).padStart(2, '0');
  };
  $('elapsedTime').textContent = '진행 ' + format(Math.floor(elapsed / 1000));
  $('remainingTime').textContent = '남은 ' + format(Math.ceil(Math.max(0, remaining) / 1000));
}
const SETTINGS_KEY = 'code-recorder.viewer.settings.v1';
function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify({
      follow: $('follow').checked, waitForContinue: $('waitForContinue').checked,
      continueDelay: $('continueDelay').value, transitionDuration: $('transitionDuration').value,
      speed: $('speed').value, studyMode
    }));
  } catch (_) { /* Playback also works when browser storage is unavailable. */ }
}
function restoreSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY));
    if (!saved || typeof saved !== 'object') return;
    for (const id of ['follow', 'waitForContinue']) {
      if (typeof saved[id] === 'boolean') $(id).checked = saved[id];
    }
    if (['0', '1', '2', '3', '4', '5'].includes(saved.continueDelay)) $('continueDelay').value = saved.continueDelay;
    if (['1', '2', '3', '4', '5'].includes(saved.transitionDuration)) $('transitionDuration').value = saved.transitionDuration;
    if (['0.5', '1', '2', '4'].includes(saved.speed)) $('speed').value = saved.speed;
    if (typeof saved.studyMode === 'boolean') studyMode = saved.studyMode;
  } catch (_) { /* Ignore corrupt or inaccessible preferences. */ }
}
const basename = path => path.split('/').pop();
function notice(message, error = false) { $('notice').textContent = message; $('notice').className = error ? 'error' : ''; }
function clearTransition() { transition = null; $('transition').hidden = true; $('continuePlayback').hidden = true; }
function pause() { playing = false; budget = 0; resumeAt = 0; clearTransition(); $('play').textContent = '▶ 자동 보기'; }
function showTransition(from, target, pendingIndex = null) {
  if (!target || !from || from.fileId === target.fileId) return;
  $('transitionFrom').textContent = basename(from.path);
  $('transitionTitle').textContent = basename(target.path);
  $('transitionPath').textContent = target.path;
  $('transition').hidden = false;
  transition = { until: performance.now() + transitionDurationMs(), pendingIndex, waiting: $('waitForContinue').checked };
  $('continuePlayback').hidden = !transition.waiting;
}
function load(text, name) {
  pause();
  const parsed = CodeReplay.parseRecording(text);
  lesson = parsed; replay = new CodeReplay.Replay(lesson); selected = replay.active; renderKey = '';
  steps = CodeReplay.buildStudySteps(lesson); stepIndex = 0; visited = new Set(); folders = new Map();
  playbackEnds = CodeReplay.buildPlaybackEnds(lesson);
  buildTimeIndex();
  const options = document.createDocumentFragment();
  const first = document.createElement('option'); first.value = '0'; first.textContent = '0 · 시작 코드'; options.append(first);
  steps.forEach((step, i) => {
    const option = document.createElement('option'); option.value = i + 1;
    option.textContent = `${i + 1} · ${step.path} · ${step.line ? step.line + '줄 수정' : labels[step.type]}`; options.append(option);
  });
  $('stepSelect').replaceChildren(options);
  $('welcome').hidden = true; $('workspace').hidden = false;
  $('title').textContent = name.replace(/\.coderec\.json$|\.journal\.jsonl$/i, '');
  $('progress').max = Math.max(lesson.events.length, 1); $('progress').disabled = !lesson.events.length;
  $('eventCount').textContent = `${steps.length}단계`;
  notice(lesson.recovered || lesson.incomplete ? '복구 기록입니다. 마지막으로 남은 변경까지 볼 수 있습니다.' : '');
  setMode(studyMode);
}
function setMode(manual) {
  pause(); studyMode = manual;
  updateOptionAvailability();
  saveSettings();
  $('stepMode').setAttribute('aria-pressed', String(manual)); $('autoMode').setAttribute('aria-pressed', String(!manual));
  $('study').hidden = !manual; $('autoControls').hidden = manual; $('stepChanges').hidden = true;
  if (manual && replay) goStep(replay.cursor <= steps.initialEnd ? 0 : steps.filter(step => step.end <= replay.cursor).length);
  else { renderKey = ''; render(); }
}
function goStep(index) {
  if (!replay) return;
  pause(); stepIndex = Math.max(0, Math.min(index, steps.length));
  $('stepSelect').value = stepIndex; $('previousStep').disabled = stepIndex === 0; $('nextStep').disabled = stepIndex === steps.length;
  $('stepChanges').hidden = true;
  if (stepIndex === 0) {
    replay.reset();
    replay.seekEvent(steps.initialEnd); selected = replay.active;
    $('stepSummary').textContent = steps.length
      ? `시작 상태 · 전체 ${steps.length}단계. 읽고 따라 친 뒤 다음 단계를 누르세요.`
      : '별도로 볼 코드 변경 단계가 없습니다. import·공백·빈 줄 변경은 반영했습니다.';
  } else {
    const step = steps[stepIndex - 1];
    replay.seekEvent(step.start);
    const before = replay.files.get(step.fileId)?.text || '';
    replay.seekEvent(step.end);
    const after = replay.files.get(step.fileId)?.text || '';
    selected = replay.files.has(step.fileId) ? step.fileId : replay.active;
    const changes = CodeReplay.changedText(before, after);
    const target = step.type === 'move' ? `${step.path} → ${step.newPath}` : step.path;
    $('stepSummary').textContent = `${stepIndex} / ${steps.length}단계 · ${target} · ${labels[step.type]}` +
      (changes.changed ? ` · ${changes.line}줄부터 변경` : '') + (stepIndex === steps.length ? ' · 마지막 단계입니다.' : '');
    if (changes.changed) {
      $('beforeCode').textContent = changes.before || '(내용 없음)'; $('afterCode').textContent = changes.after || '(내용 없음)';
      $('stepChanges').hidden = false;
    }
  }
  renderKey = ''; render();
  const step = steps[stepIndex - 1];
  if (step?.type === 'transition') {
    $('transitionFrom').textContent = step.fromPath ? basename(step.fromPath) : '수업 시작';
    $('transitionTitle').textContent = basename(step.path);
    $('transitionPath').textContent = step.path;
    $('transition').hidden = false;
    // Manual dividers are real steps: they remain until the student navigates.
    transition = { manual: true };
  }
}
function chooseFile(id) { selected = id; $('follow').checked = false; updateOptionAvailability(); saveSettings(); clearTransition(); render(); }
function fileButton(file) {
  const button = document.createElement('button'); button.className = file.fileId === selected ? 'selected' : '';
  const icon = document.createElement('span'); icon.className = 'file-icon';
  icon.textContent = /\.java$/i.test(file.path) ? 'J' : /\.xml$/i.test(file.path) ? 'M' : '◇';
  button.append(icon, document.createTextNode(basename(file.path)));
  button.title = file.path; button.setAttribute('aria-pressed', String(file.fileId === selected));
  button.onclick = () => chooseFile(file.fileId); return button;
}
function renderFiles() {
  const tree = { directories: new Map(), files: [] };
  for (const file of [...replay.files.values()].sort((a,b) => a.path.localeCompare(b.path))) {
    let node = tree;
    for (const part of file.path.split('/').slice(0, -1)) {
      if (!node.directories.has(part)) node.directories.set(part, { directories: new Map(), files: [] });
      node = node.directories.get(part);
    }
    node.files.push(file);
  }
  const fill = (node, parent, prefix) => {
    for (const [name, child] of node.directories) {
      const key = prefix + name + '/', details = document.createElement('details'), summary = document.createElement('summary');
      const label = document.createElement('span'); label.className = 'folder-label'; label.textContent = name; summary.append(label);
      details.open = folders.get(key) !== false; details.append(summary);
      summary.onclick = () => folders.set(key, !details.open);
      fill(child, details, key); parent.append(details);
    }
    for (const file of node.files) parent.append(fileButton(file));
  };
  const root = document.createElement('details'), summary = document.createElement('summary');
  root.open = folders.get('/') !== false;
  summary.textContent = '▣ ' + (lesson.root ? basename(lesson.root) : '수업 프로젝트'); summary.onclick = () => folders.set('/', !root.open);
  root.append(summary); fill(tree, root, ''); $('files').replaceChildren(root);
  if (selected) visited.add(selected);
  const tabs = document.createDocumentFragment();
  for (const id of visited) if (replay.files.has(id)) tabs.append(fileButton(replay.files.get(id)));
  $('tabs').replaceChildren(tabs);
}
function renderCode(file) {
  const fragment = document.createDocumentFragment();
  let changed = null, lineIndex = 0;
  const edit = replay.lastEdit;
  const highlight = file && edit && edit.fileId === file.fileId ? file.text.slice(0, edit.offset).split(/\r\n|\r|\n/).length - 1 : -1;
  function newLine() {
    const line = document.createElement('span'); line.className = 'code-line';
    const number = document.createElement('span'); number.className = 'line-number'; number.textContent = ++lineIndex;
    line.append(number);
    const content = document.createElement('span'); content.className = 'code-content'; line.append(content);
    if (lineIndex - 1 === highlight) { line.classList.add('changed'); changed = line; }
    fragment.append(line); return content;
  }
  if (file) {
    let line = newLine();
    for (const token of CodeSyntax.tokenize(file.text, file.path)) {
      const parts = token.text.split(/\r\n|\r|\n/);
      parts.forEach((text, i) => {
        if (i) line = newLine();
        if (text) { const span = document.createElement('span'); span.className = token.kind ? 'syntax-' + token.kind : ''; span.textContent = text; line.append(span); }
      });
    }
  }
  $('code').replaceChildren(fragment);
  if (changed && $('follow').checked) {
    const view = $('codeScroll'), relative = changed.getBoundingClientRect().top - view.getBoundingClientRect().top;
    const bottomLimit = Math.max(0, view.clientHeight - (changed.offsetHeight || 27) - 200);
    if (relative < 0) view.scrollTop += relative - view.clientHeight / 2;
    else if (relative > bottomLimit) view.scrollTop += relative - bottomLimit;
  }
}
function render() {
  if (!replay) return;
  renderTimes();
  if ($('follow').checked) {
    const stepFile = studyMode && stepIndex > 0 ? steps[stepIndex - 1].fileId : null;
    selected = replay.files.has(stepFile) ? stepFile : replay.active;
  }
  if (!replay.files.has(selected)) selected = replay.active;
  $('position').textContent = `${replay.cursor} / ${lesson.events.length} 순서`; $('progress').value = replay.cursor;
  const file = replay.files.get(selected), key = `${replay.cursor}:${selected}`;
  if (key === renderKey) return;
  renderKey = key; renderFiles(); renderCode(file);
  $('path').textContent = file ? file.path : '파일 없음';
}
$('stepMode').onclick = () => setMode(true);
$('autoMode').onclick = () => setMode(false);
$('previousStep').onclick = () => goStep(stepIndex - 1);
$('nextStep').onclick = () => goStep(stepIndex + 1);
$('stepSelect').onchange = () => goStep(Number($('stepSelect').value));
$('file').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return;
  pause(); const generation = ++loadGeneration;
  try {
    if (file.size > 128 * 1024 * 1024) throw new Error('최대 128MB 파일을 열 수 있습니다.');
    const text = await file.text(); if (generation !== loadGeneration) return; load(text, file.name);
  } catch (error) { notice(error.message, true); }
  event.target.value = '';
});
$('play').onclick = () => {
  if (!replay || studyMode || !lesson.events.length) return;
  if (playing) { pause(); return; }
  if (replay.cursor >= lesson.events.length) replay.seekEvent(0);
  playing = true; budget = 0; lastFrame = performance.now(); $('play').textContent = 'Ⅱ 일시정지'; render();
};
$('restart').onclick = () => { pause(); replay.reset(); renderKey = ''; render(); };
$('progress').oninput = () => {
  pause(); const count = Number($('progress').value);
  if (count === 0) { replay.reset(); renderKey = ''; }
  replay.seekEvent(count ? playbackEnds[count - 1] : 0); render();
};
$('follow').onchange = () => { updateOptionAvailability(); saveSettings(); clearTransition(); render(); };
$('transitionDuration').onchange = () => {
  saveSettings(); renderTimes();
  if (transition && !transition.manual && !transition.waiting && !resumeAt)
    transition.until = performance.now() + transitionDurationMs();
};
$('continueDelay').onchange = () => { saveSettings(); renderTimes(); };
$('speed').onchange = () => { saveSettings(); renderTimes(); };
$('waitForContinue').onchange = () => {
  updateOptionAvailability();
  saveSettings();
  renderTimes();
  if (!transition || transition.manual) return;
  transition.waiting = $('waitForContinue').checked;
  transition.until = performance.now() + transitionDurationMs();
  $('continuePlayback').hidden = !transition.waiting;
};
$('continuePlayback').onclick = () => {
  if (!playing || !transition?.waiting || transition.manual) return;
  const delay = Math.max(0, Math.min(5, Number($('continueDelay').value) || 0));
  const pending = transition.pendingIndex;
  clearTransition();
  if (pending === replay.cursor) {
    // Show the destination now, but leave its first edit pending until the delay ends.
    const event = lesson.events[pending];
    if (event.type === 'activate' || event.type === 'create') replay.seekEvent(pending + 1);
    else replay.active = event.fileId;
    selected = replay.active;
  }
  resumeAt = delay > 0 ? performance.now() + delay * 1000 : 0;
  budget = 0; lastFrame = performance.now(); render();
};
document.addEventListener('keydown', event => {
  if (event.code !== 'Space' || event.isComposing || event.altKey || event.ctrlKey || event.metaKey ||
      !playing || !transition?.waiting || transition.manual) return;
  const target = event.target;
  if (target?.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target?.tagName || '')) return;
  event.preventDefault();
  if (!event.repeat) $('continuePlayback').onclick();
});
function tick(now) {
  if (playing && resumeAt) {
    if (now < resumeAt) { lastFrame = now; requestAnimationFrame(tick); return; }
    resumeAt = 0; budget = EDIT_INTERVAL_MS; lastFrame = now;
  }
  if (transition && !transition.manual) {
    if (transition.waiting || now < transition.until) { lastFrame = now; requestAnimationFrame(tick); return; }
    const pending = transition.pendingIndex; clearTransition();
    if (playing && pending === replay.cursor) { replay.seekEvent(playbackEnds[pending]); render(); }
    budget = 0; lastFrame = now;
  }
  if (playing) {
    budget += Math.min(now - lastFrame, 250) * Number($('speed').value);
    if (replay.cursor >= lesson.events.length) pause();
    else if (budget >= EDIT_INTERVAL_MS) {
      const event = lesson.events[replay.cursor];
      const from = replay.files.get(selected);
      const target = event.type === 'end' ? null : { fileId: event.fileId, path: event.newPath || event.path };
      if ($('follow').checked && from && target && from.fileId !== target.fileId) showTransition(from, target, replay.cursor);
      else { replay.seekEvent(playbackEnds[replay.cursor]); render(); }
      budget = 0;
      if (replay.cursor >= lesson.events.length) pause();
    }
  }
  lastFrame = now; requestAnimationFrame(tick);
}
restoreSettings();
updateOptionAvailability();
requestAnimationFrame(tick);
$('openAnother').onclick = () => $('file').click();
