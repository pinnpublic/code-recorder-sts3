sts3.png: Spring Tool Suite 3 icon (sts48.png), copied without modification
from org.springsource.sts_3.9.18.202109140905-RELEASE.jar in the local STS3 installation.
The source bundle's accompanying notice is preserved in sts3-about.html.
