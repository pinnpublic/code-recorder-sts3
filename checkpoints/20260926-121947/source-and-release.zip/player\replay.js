(function (global) {
  'use strict';
  const MAX_TEXT = 128 * 1024 * 1024;
  function assert(condition, message) { if (!condition) throw new Error(message); }
  function string(value, label) { assert(typeof value === 'string', label + ' 값이 올바르지 않습니다.'); return value; }
  function path(value) {
    string(value, '파일 경로');
    assert(value.length > 0 && !value.startsWith('/') && !value.includes('\\') &&
      !value.split('/').some(p => p === '..' || p === '.' || !p), '잘못된 상대 경로입니다.');
    return value;
  }
  function parseRecording(text) {
    assert(text.length <= MAX_TEXT, '녹화 파일이 너무 큽니다 (최대 128MB).');
    let data, recovered = false, incomplete = false;
    try { data = JSON.parse(text); }
    catch (original) {
      // Recovery journal: one header, then one complete event per line.
      const lines = text.trimEnd().split(/\r?\n/);
      assert(lines.length > 0, '빈 파일입니다.');
      try { data = JSON.parse(lines[0]); } catch (_) { throw new Error('녹화 파일 형식이 올바르지 않습니다.'); }
      data.events = [];
      for (let i = 1; i < lines.length; i++) {
        try { data.events.push(JSON.parse(lines[i])); }
        catch (_) {
          assert(i === lines.length - 1, '복구 기록 중간에 손상된 줄이 있습니다.');
          incomplete = true;
        }
      }
      recovered = true;
    }
    assert(data && data.format === 'code-recorder' && [1, 2].includes(data.version), '지원하지 않는 녹화 형식입니다.');
    assert(Array.isArray(data.initial), '초기 파일 목록이 없습니다.');
    // A journal containing only its header is still recoverable.
    if (!Array.isArray(data.events) && data.events === undefined) { data.events = []; recovered = true; }
    assert(Array.isArray(data.events), '이벤트 목록이 없습니다.');
    let seq = 0, ended = false;
    const ids = new Set(), paths = new Set();
    for (const f of data.initial) {
      string(f.fileId, '파일 ID'); path(f.path); string(f.text, '코드');
      assert(!ids.has(f.fileId) && !paths.has(f.path), '초기 파일이 중복되었습니다.');
      ids.add(f.fileId); paths.add(f.path);
    }
    for (const e of data.events) {
      assert(e && Number.isSafeInteger(e.seq) && e.seq === ++seq, '이벤트 순서가 손상되었습니다.');
      assert(!ended, '종료 뒤에 이벤트가 있습니다.');
      assert(['create', 'edit', 'activate', 'delete', 'move', 'end'].includes(e.type), '알 수 없는 이벤트입니다.');
      if (e.type === 'end') { ended = true; continue; }
      string(e.fileId, '파일 ID'); path(e.path);
      if (e.type === 'create') { string(e.text, '코드'); assert(!ids.has(e.fileId), '재사용된 파일 ID입니다.'); ids.add(e.fileId); }
      if (e.type === 'edit') {
        assert(Number.isSafeInteger(e.offset) && e.offset >= 0, '잘못된 수정 위치입니다.');
        string(e.removedText, '삭제 내용'); string(e.insertedText, '입력 내용');
      }
      if (e.type === 'move') path(e.newPath);
    }
    // Legacy timestamps are intentionally ignored, including for step grouping.
    const recording = { ...data, recovered, incomplete: incomplete || !ended };
    // Validate every replacement before displaying a potentially corrupt lesson.
    const check = new Replay(recording); check.seekEvent(recording.events.length);
    return recording;
  }
  class Replay {
    constructor(recording) { this.recording = recording; this.reset(); }
    reset() {
      this.files = new Map(this.recording.initial.map(f => [f.fileId, { ...f }]));
      this.active = this.files.keys().next().value || null;
      this.cursor = 0; this.lastEdit = null;
    }
    apply(e) {
      if (e.type === 'end') return;
      let file = this.files.get(e.fileId);
      if (e.type === 'create') {
        assert(!file && ![...this.files.values()].some(f => f.path === e.path), '생성 파일이 중복되었습니다.');
        this.files.set(e.fileId, { fileId: e.fileId, path: e.path, text: e.text });
        this.active = e.fileId;
        return;
      }
      assert(file && file.path === e.path, '이벤트의 파일을 찾을 수 없습니다: ' + e.path);
      switch (e.type) {
        case 'edit':
          assert(e.offset + e.removedText.length <= file.text.length &&
            file.text.slice(e.offset, e.offset + e.removedText.length) === e.removedText,
            '코드 복원 불일치: ' + e.path);
          file.text = file.text.slice(0, e.offset) + e.insertedText + file.text.slice(e.offset + e.removedText.length);
          this.lastEdit = { fileId: e.fileId, offset: e.offset, seq: e.seq };
          this.active = e.fileId;
          break;
        case 'activate': this.active = e.fileId; break;
        case 'delete':
          this.files.delete(e.fileId);
          if (this.active === e.fileId) this.active = this.files.keys().next().value || null;
          break;
        case 'move':
          assert(![...this.files.values()].some(f => f.path === e.newPath), '이동 경로가 중복되었습니다.');
          file.path = e.newPath; this.active = e.fileId; break;
      }
    }
    seekEvent(count) {
      assert(Number.isSafeInteger(count) && count >= 0 && count <= this.recording.events.length, '잘못된 복습 단계입니다.');
      // Use event order, not timestamps: several edits may share the same millisecond.
      if (count < this.cursor) this.reset();
      while (this.cursor < count) this.apply(this.recording.events[this.cursor++]);
      return this;
    }
  }
  function buildPlaybackEnds(recording) {
    const events = recording.events, ends = events.map((_, i) => i + 1);
    const hangul = text => /^[\u1100-\u11ff\u3131-\u318e\uac00-\ud7a3]$/.test(text);
    for (let i = 0; i < events.length; i++) {
      const first = events[i];
      if (first.type !== 'edit' || first.removedText !== '' || !/^[\u1100-\u11ff\u3131-\u318e]$/.test(first.insertedText)) continue;
      const same = e => e && e.type === 'edit' && e.fileId === first.fileId && e.path === first.path && e.offset === first.offset;
      let text = first.insertedText, end = i + 1;
      while (same(events[end])) {
        const event = events[end];
        if (event.removedText === text && hangul(event.insertedText)) {
          text = event.insertedText; end++; continue;
        }
        // STS commits a composed syllable by removing and reinserting it.
        // Consume only that exact pair, leaving later user deletions untouched.
        const commit = events[end + 1];
        if (event.removedText === text && event.insertedText === '' && same(commit) &&
            commit.removedText === '' && commit.insertedText === text) end += 2;
        break;
      }
      for (let index = i; index < end; index++) ends[index] = end;
      i = end - 1;
    }
    // Use the same line grouping as manual review to recognize fully typed imports.
    // Keep mixed code/import pastes intact rather than hiding unrelated edits.
    buildSteps(recording, (start, end) => {
      for (let index = start; index < end; index++) ends[index] = Math.max(ends[index], end);
    });
    return ends;
  }
  function buildSteps(recording, onImport = () => {}) {
    const steps = [], state = new Replay(recording);
    steps.initialEnd = 0;
    let group = null;
    const lineAt = (text, offset) => text.slice(0, offset).split(/\r\n|\r|\n/).length;
    // Inspect only changed lines, excluding an untouched line after a newline insertion.
    function importOnly(before, after, name) {
      if (!/\.java$/i.test(name)) return false;
      let start = 0, oldEnd = before.length, newEnd = after.length;
      while (start < oldEnd && start < newEnd && before[start] === after[start]) start++;
      while (oldEnd > start && newEnd > start && before[oldEnd - 1] === after[newEnd - 1]) { oldEnd--; newEnd--; }
      const lines = (text, end) => {
        if (end === start) return [];
        const begin = Math.max(text.lastIndexOf('\n', start - 1), text.lastIndexOf('\r', start - 1)) + 1;
        const tail = /[\r\n]/.exec(text.slice(end - 1));
        return text.slice(begin, tail ? end - 1 + tail.index : text.length).split(/\r\n|\r|\n/).filter(s => s.trim());
      };
      const touched = [...lines(before, oldEnd), ...lines(after, newEnd)];
      return touched.length > 0 && touched.every(s => /^\s*import\b/.test(s));
    }
    function finish() {
      if (!group) return;
      const { before, after, whitespace, ...step } = group;
      const isImport = importOnly(before, after, step.path);
      if (isImport) onImport(step.start, step.end);
      if (whitespace || before === after || isImport) {
        // Keep every event for exact reconstruction, but do not require another click.
        if (steps.length) steps[steps.length - 1].end = step.end;
        else steps.initialEnd = step.end;
      } else steps.push(step);
      group = null;
    }
    recording.events.forEach((event, index) => {
      if (event.type !== 'edit') {
        finish(); state.seekEvent(index + 1);
        if (event.type !== 'end') steps.push({ start: index, end: index + 1,
          type: event.type, fileId: event.fileId, path: event.path, newPath: event.newPath });
        return;
      }
      const before = state.files.get(event.fileId).text;
      const line = lineAt(before, event.offset);
      const whitespace = !event.insertedText.trim() && !event.removedText.trim();
      // A multi-line paste/replacement stays one operation. A terminating Enter is
      // included with its line; edits on the next line start a new group.
      const multiline = /[\r\n]/.test(event.insertedText.trim()) || /[\r\n]/.test(event.removedText.trim());
      if (group && (group.fileId !== event.fileId || group.line !== line || group.multiline || multiline ||
          (group.whitespace && !whitespace))) finish();
      state.seekEvent(index + 1);
      const after = state.files.get(event.fileId).text;
      if (group) {
        group.end = index + 1; group.after = after; group.whitespace &&= whitespace;
      } else {
        group = { start: index, end: index + 1, type: 'edit', fileId: event.fileId,
          path: event.path, line, multiline, before, after, whitespace };
      }
    });
    finish();
    return steps;
  }
  function buildStudySteps(recording) {
    const base = buildSteps(recording), steps = [], state = new Replay(recording);
    steps.initialEnd = base.initialEnd;
    state.seekEvent(base.initialEnd);
    for (const step of base) {
      state.seekEvent(step.start);
      const from = state.files.get(state.active);
      const changesFile = step.fileId !== state.active && step.type !== 'delete';
      if (changesFile) {
        steps.push({ type: 'transition', fileId: step.fileId, path: step.path,
          fromPath: from?.path || '', start: step.start,
          end: step.type === 'activate' ? step.end : step.start });
      }
      if (!(changesFile && step.type === 'activate')) steps.push(step);
      state.seekEvent(step.end);
    }
    return steps;
  }
  function changedText(before, after) {
    let start = 0, oldEnd = before.length, newEnd = after.length;
    while (start < oldEnd && start < newEnd && before[start] === after[start]) start++;
    while (oldEnd > start && newEnd > start && before[oldEnd - 1] === after[newEnd - 1]) { oldEnd--; newEnd--; }
    // Expand to whole lines so students can read and copy the changed code in context.
    const lineStart = text => start === 0 ? 0 : Math.max(text.lastIndexOf('\n', start - 1), text.lastIndexOf('\r', start - 1)) + 1;
    const lineEnd = (text, offset) => { const match = /[\r\n]/.exec(text.slice(offset)); return match ? offset + match.index : text.length; };
    return { before: before === after ? '' : before.slice(lineStart(before), lineEnd(before, oldEnd)),
      after: before === after ? '' : after.slice(lineStart(after), lineEnd(after, newEnd)),
      line: before.slice(0, start).split(/\r\n|\r|\n/).length, changed: before !== after };
  }
  const api = { parseRecording, Replay, buildSteps, buildStudySteps, buildPlaybackEnds, changedText };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else global.CodeReplay = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
