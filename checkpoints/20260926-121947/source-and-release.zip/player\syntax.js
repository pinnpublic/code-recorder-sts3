(function (global) {
  'use strict';
  // Tokens are rendered using text nodes, never HTML from recorded source.
  function tokenize(text, filename) {
    const xml = /\.(?:xml|jsp|jspx|html|htm)$/i.test(filename);
    const pattern = xml
      ? /<!--[\s\S]*?(?:-->|$)|"[^"\n]*"|'[^'\n]*'|<\/?[\w:.-]+|\/?>/g
      : /\/\*[\s\S]*?(?:\*\/|$)|\/\/[^\r\n]*|"(?:\\.|[^"\\\r\n])*"|'(?:\\.|[^'\\\r\n])*'|@[\w.]+|\b(?:package|import|public|private|protected|class|interface|enum|extends|implements|static|final|void|return|new|if|else|for|while|try|catch|throw|throws|true|false|null|int|long|boolean|double|float|char|byte|short|this|super|const|let|var|function|export|async|await)\b|\b\d+(?:\.\d+)?\b|\b[A-Z][A-Za-z0-9_]*\b/g;
    let cursor = 0;
    const tokens = [];
    for (const match of text.matchAll(pattern)) {
      if (match.index > cursor) tokens.push({ text: text.slice(cursor, match.index), kind: '' });
      const value = match[0];
      const kind = /^(?:\/\/|\/\*|<!--)/.test(value) ? 'comment'
        : /^["']/.test(value) ? 'string' : xml ? 'tag' : value[0] === '@' ? 'annotation'
        : /^\d/.test(value) ? 'number' : /^[A-Z]/.test(value) ? 'type' : 'keyword';
      tokens.push({ text: value, kind }); cursor = match.index + value.length;
    }
    if (cursor < text.length) tokens.push({ text: text.slice(cursor), kind: '' });
    return tokens;
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { tokenize };
  else global.CodeSyntax = { tokenize };
})(typeof globalThis !== 'undefined' ? globalThis : this);
