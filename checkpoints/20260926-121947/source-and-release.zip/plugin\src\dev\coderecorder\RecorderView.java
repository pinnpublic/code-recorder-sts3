package dev.coderecorder;

import java.nio.file.Paths;
import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;
import org.eclipse.ui.part.ViewPart;

public final class RecorderView extends ViewPart {
    public static final String ID = "dev.coderecorder.view";
    private Text folder, excludes, extensions;
    private Label status, badge;
    private Color ink, muted, green, amber, white;
    private Font heading, bold;
    private Button start, stop, browse;
    private RecorderService service;
    public void createPartControl(Composite parent) {
        service = Activator.getDefault().recorder();
        Display display = parent.getDisplay();
        Color background = new Color(display, 243, 246, 249);
        Color tint = new Color(display, 232, 244, 237);
        ink = new Color(display, 34, 48, 64); muted = new Color(display, 91, 108, 123);
        green = new Color(display, 30, 112, 75); amber = new Color(display, 145, 91, 15);
        white = new Color(display, 255, 255, 255);
        FontData base = parent.getFont().getFontData()[0];
        bold = new Font(display, base.getName(), base.getHeight(), SWT.BOLD);
        heading = new Font(display, base.getName(), base.getHeight() + 4, SWT.BOLD);
        parent.addDisposeListener(e -> {
            heading.dispose(); bold.dispose();
            for (Color color : new Color[] { background, tint, ink, muted, green, amber, white }) color.dispose();
        });
        parent.setLayout(new FillLayout());
        ScrolledComposite scroll = new ScrolledComposite(parent, SWT.V_SCROLL);
        scroll.setExpandHorizontal(true); scroll.setExpandVertical(true);
        Composite body = new Composite(scroll, SWT.NONE);
        body.setBackground(background); body.setLayout(layout(1, 16, 12)); scroll.setContent(body);

        Composite header = new Composite(body, SWT.NONE);
        header.setBackground(tint); header.setBackgroundMode(SWT.INHERIT_DEFAULT);
        header.setLayout(layout(2, 16, 6)); header.setLayoutData(fill());
        Label title = label(header, "Code Recorder", green); title.setFont(heading);
        badge = label(header, "● 준비", green); badge.setFont(bold);
        badge.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false));
        Label subtitle = label(header, "수업의 작성 과정을, 학생의 복습 자료로.", muted);
        subtitle.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));

        Composite target = card(body);
        section(target, "01  녹화 대상");
        label(target, "기록할 프로젝트 또는 폴더를 선택하세요.", muted);
        Composite picker = new Composite(target, SWT.NONE);
        picker.setLayout(layout(2, 0, 0)); picker.setLayoutData(fill());
        folder = new Text(picker, SWT.BORDER | SWT.READ_ONLY); folder.setBackground(white);
        folder.setLayoutData(fill()); folder.setToolTipText("선택한 폴더 안의 코드 변경을 기록합니다.");
        browse = new Button(picker, SWT.PUSH); browse.setText("폴더 선택…");
        browse.addListener(SWT.Selection, e -> {
            ContainerSelectionDialog dialog = new ContainerSelectionDialog(parent.getShell(), ResourcesPlugin.getWorkspace().getRoot(), false, "녹화할 프로젝트 또는 폴더를 선택하세요.");
            dialog.showClosedProjects(false);
            if (dialog.open() == Window.OK && dialog.getResult().length > 0) folder.setText(((IPath) dialog.getResult()[0]).toPortableString());
        });
        Composite settings = card(body);
        section(settings, "02  기록 범위");
        label(settings, "제외할 폴더·파일 이름", ink);
        excludes = new Text(settings, SWT.BORDER); excludes.setText(RecorderService.DEFAULT_EXCLUDES); excludes.setLayoutData(fill());
        label(settings, "기록할 확장자", ink);
        extensions = new Text(settings, SWT.BORDER); extensions.setText(RecorderService.EXTENSIONS); extensions.setLayoutData(fill());
        label(settings, "쉼표로 구분합니다. 숨김 경로와 빌드 산출물은 제외됩니다.", muted);

        Composite recording = card(body);
        section(recording, "03  수업 기록");
        label(recording, "저장하지 않은 편집도 기록합니다. 수업이 끝나면 종료 / 내보내기를 누르세요.", muted);
        Composite actions = new Composite(recording, SWT.NONE);
        actions.setLayout(layout(2, 0, 0)); actions.setLayoutData(fill());
        start = new Button(actions, SWT.PUSH); start.setText("● 녹화 시작"); start.setFont(bold);
        stop = new Button(actions, SWT.PUSH); stop.setText("■ 종료 / 내보내기");
        GridData startSize = new GridData(SWT.LEFT, SWT.CENTER, false, false); startSize.heightHint = 34; start.setLayoutData(startSize);
        GridData stopSize = new GridData(SWT.LEFT, SWT.CENTER, false, false); stopSize.heightHint = 34; stop.setLayoutData(stopSize);
        status = label(recording, "", muted);
        scroll.addListener(SWT.Resize, e -> scroll.setMinSize(body.computeSize(Math.max(260, scroll.getClientArea().width), SWT.DEFAULT)));
        start.addListener(SWT.Selection, e -> {
            IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(folder.getText());
            if (!(resource instanceof IContainer)) { MessageDialog.openInformation(parent.getShell(), "Code Recorder", "기록할 프로젝트나 폴더를 먼저 선택하세요."); return; }
            FileDialog save = new FileDialog(parent.getShell(), SWT.SAVE);
            save.setText("녹화 파일 저장 위치 (대상 폴더 밖)"); save.setFilterExtensions(new String[] {"*.coderec.json"});
            save.setFileName("lesson-" + java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".coderec.json");
            String path = save.open(); if (path == null) return;
            try { service.start((IContainer) resource, Paths.get(path), excludes.getText(), extensions.getText()); }
            catch (Exception error) { MessageDialog.openError(parent.getShell(), "녹화 시작 실패", error.getMessage()); }
            update();
        });
        stop.addListener(SWT.Selection, e -> { service.stop(); update(); });
        Runnable timer = new Runnable() {
            public void run() { if (parent.isDisposed()) return; update(); parent.getDisplay().timerExec(500, this); }
        };
        timer.run();
    }
    private void update() {
        start.setEnabled(!service.isBusy()); stop.setEnabled(service.isRecording()); browse.setEnabled(!service.isBusy());
        excludes.setEnabled(!service.isBusy()); extensions.setEnabled(!service.isBusy());
        String message = service.status();
        String state = service.isRecording() ? "● 녹화 중" : service.isBusy() ? "● 내보내는 중" : "● 준비";
        if (!message.equals(status.getText()) || !state.equals(badge.getText())) {
            status.setText(message); badge.setText(state);
            badge.setForeground(service.isRecording() ? green : service.isBusy() ? amber : muted);
            status.getParent().layout(true, true); badge.getParent().layout(true, true);
        }
    }
    private GridLayout layout(int columns, int margin, int spacing) {
        GridLayout layout = new GridLayout(columns, false);
        layout.marginWidth = margin; layout.marginHeight = margin;
        layout.horizontalSpacing = 12; layout.verticalSpacing = spacing;
        return layout;
    }
    private GridData fill() { return new GridData(SWT.FILL, SWT.CENTER, true, false); }
    private Composite card(Composite parent) {
        Composite card = new Composite(parent, SWT.NONE);
        card.setBackground(white); card.setBackgroundMode(SWT.INHERIT_DEFAULT);
        card.setLayout(layout(1, 16, 9)); card.setLayoutData(fill()); return card;
    }
    private Label label(Composite parent, String text, Color color) {
        Label label = new Label(parent, SWT.WRAP); label.setText(text); label.setForeground(color);
        GridData data = fill(); data.widthHint = 200; label.setLayoutData(data); return label;
    }
    private void section(Composite parent, String text) { label(parent, text, green).setFont(bold); }
    public void setFocus() { if (start != null) start.setFocus(); }
}
