const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');

// Minimal DOM harness for student navigation behavior; this is not visual browser QA.
class Element {
  constructor(tag = '') { this.tag = tag; this.children = []; this.attributes = {}; this.textContent = ''; this.value = ''; this.checked = false; this.classList = { add() {} }; }
  append(...items) { for (const item of items) this.children.push(...(item.tag === 'fragment' ? item.children : [item])); }
  replaceChildren(...items) { this.children = []; this.append(...items); }
  setAttribute(name, value) { this.attributes[name] = value; }
  addEventListener(name, handler) { this['on' + name] = handler; }
  getBoundingClientRect() { return { top: 0 }; }
  text() { return this.textContent + this.children.map(c => c.text()).join(''); }
}
function harness(storage = new Map()) {
  const elements = new Map();
  const html = fs.readFileSync(path.join(__dirname, '../player/index.html'), 'utf8');
  for (const match of html.matchAll(/id="([^"]+)"/g)) elements.set(match[1], new Element());
  const get = id => { assert.ok(elements.has(id), 'Missing HTML control: ' + id); return elements.get(id); };
  get('follow').checked = true; get('speed').value = '1';
  get('waitForContinue').checked = /id="waitForContinue"[^>]*\bchecked\b/.test(html);
  get('continueDelay').value = '0';
  get('transitionDuration').value = '2';
  let now = 0;
  const context = vm.createContext({
    localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) },
    CodeReplay: require('../player/replay.js'),
    CodeSyntax: require('../player/syntax.js'),
    document: { addEventListener: (name, handler) => { context['on' + name] = handler; }, getElementById: get, createDocumentFragment: () => new Element('fragment'),
      createElement: tag => new Element(tag), createTextNode: text => Object.assign(new Element(), { textContent: text }) },
    performance: { now: () => now }, requestAnimationFrame: callback => { context.frame = callback; }
  });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../player/app.js'), 'utf8'), context);
  return { get, context, tick: ms => { now += ms; context.frame(now); } };
}
test('student opens a recording and controls each step, with file transition cards and familiar file tabs', async () => {
  const { get, tick } = harness();
  const file = { name: 'navigation.coderec.json', size: 2000,
    text: async () => fs.readFileSync(path.join(__dirname, 'fixtures/navigation.coderec.json'), 'utf8') };
  await get('file').onchange({ target: { files: [file], value: 'navigation.coderec.json' } });
  assert.equal(get('study').hidden, true);
  assert.equal(get('autoControls').hidden, false);
  assert.equal(get('autoMode').attributes['aria-pressed'], 'true');
  get('stepMode').onclick();
  assert.equal(get('study').hidden, false);
  assert.equal(get('autoControls').hidden, true);
  assert.equal(get('previousStep').disabled, true);
  const initial = get('code').text();
  tick(60000);
  assert.equal(get('code').text(), initial, 'must wait for the student indefinitely');
  get('nextStep').onclick(); // File activation.
  get('nextStep').onclick(); // First edit.
  assert.match(get('code').text(), /첫 번째 요청 처리/);
  assert.equal(get('stepChanges').hidden, false);
  assert.match(get('afterCode').textContent, /첫 번째 요청 처리/);
  tick(60000);
  assert.doesNotMatch(get('code').text(), /public String hello/);
  get('previousStep').onclick();
  assert.equal(get('code').text(), initial);
  get('stepSelect').value = '5'; get('stepSelect').onchange();
  assert.match(get('path').textContent, /ex01.jsp$/);
  assert.match(get('code').text(), /안녕하세요/);
  assert.match(get('files').text(), /src/);
  assert.match(get('tabs').text(), /DataController.java/);
  assert.match(get('tabs').text(), /ex01.jsp/);
  assert.equal(get('transition').hidden, true);
  get('previousStep').onclick(); // The file divider is a selectable step.
  assert.equal(get('transition').hidden, false);
  assert.equal(get('transitionTitle').textContent, 'ex01.jsp');
  assert.match(get('stepSummary').textContent, /파일 전환 안내/);
  tick(60000); assert.equal(get('transition').hidden, false);
  get('nextStep').onclick();
  assert.equal(get('transition').hidden, true);
  assert.match(get('code').text(), /안녕하세요/);
  get('autoMode').onclick();
  get('waitForContinue').checked = false;
  assert.equal(get('study').hidden, true);
  assert.equal(get('autoControls').hidden, false);
  get('play').onclick();
  for (let i = 0; i < 30; i++) tick(100);
  assert.equal(get('play').textContent, '▶ 자동 보기');
  get('stepMode').onclick();
  assert.equal(get('nextStep').disabled, true);
});
test('old ten-minute gaps disappear; automatic file transition waits briefly and can be cancelled', () => {
  const { get, context, tick } = harness();
  context.input = JSON.stringify({ format: 'code-recorder', version: 1, initial: [
    { fileId: 'a', path: 'A.java', text: '' }, { fileId: 'b', path: 'B.java', text: '' }
  ], events: [
    { seq: 1, elapsedMs: 600000, type: 'edit', fileId: 'a', path: 'A.java', offset: 0, removedText: '', insertedText: 'hello' },
    { seq: 2, elapsedMs: 1200000, type: 'activate', fileId: 'b', path: 'B.java' },
    { seq: 3, elapsedMs: 1800000, type: 'edit', fileId: 'b', path: 'B.java', offset: 0, removedText: '', insertedText: 'world' },
    { seq: 4, elapsedMs: 2400000, type: 'end' }
  ] });
  vm.runInContext('load(input, "legacy")', context);
  get('waitForContinue').checked = false;
  get('autoMode').onclick(); get('play').onclick();
  tick(100); assert.match(get('code').text(), /hello/);
  tick(100); assert.equal(get('transition').hidden, false);
  assert.equal(get('transitionTitle').textContent, 'B.java');
  tick(500); assert.equal(get('path').textContent, 'A.java');
  get('play').onclick(); // Pause during the card.
  tick(5000); assert.equal(get('path').textContent, 'A.java');
  get('play').onclick(); tick(100); tick(1100);
  assert.equal(get('path').textContent, 'A.java');
  assert.equal(get('transition').hidden, false);
  tick(1100);
  assert.equal(get('path').textContent, 'B.java');
  tick(100); assert.match(get('code').text(), /world/);
  tick(100); assert.equal(get('play').textContent, '▶ 자동 보기');
  get('restart').onclick(); assert.equal(get('position').textContent, '0 / 4 순서');
});
test('syntax colors preserve exact source including comments and unsafe markup', () => {
  const { tokenize } = require('../player/syntax.js');
  for (const [name, source] of [['A.java', 'public class A {\r\n/* 한글\n주석 */ String x = "<script>"; }'],
    ['view.jsp', '<!-- comment\n--><h1 onclick="x()">안녕😀</h1>']]) {
    const tokens = tokenize(source, name);
    assert.equal(tokens.map(t => t.text).join(''), source);
    assert.ok(tokens.some(t => t.kind === 'comment'));
  }
});

test('manual navigation shows complete corrected lines, including skipped imports and spacing', () => {
  const { get, context } = harness();
  const events = []; let text = '';
  function edit(offset, removedText, insertedText) {
    events.push({ seq: events.length + 1, type: 'edit', fileId: 'a', path: 'A.java', offset, removedText, insertedText });
    text = text.slice(0, offset) + insertedText + text.slice(offset + removedText.length);
  }
  for (const c of 'import java.util.List;\n\nint x = 0;') edit(text.length, '', c);
  edit(text.indexOf('0'), '0', '1');
  for (const c of '\n\nint y = 2;') edit(text.length, '', c);
  context.input = JSON.stringify({ format: 'code-recorder', version: 2,
    initial: [{ fileId: 'a', path: 'A.java', text: '' }], events });
  vm.runInContext('load(input, "lines")', context);
  get('stepMode').onclick();
  assert.equal(get('eventCount').textContent, '2단계');
  assert.match(get('code').text(), /import java.util.List;/);
  assert.doesNotMatch(get('code').text(), /int x/);
  get('nextStep').onclick();
  assert.match(get('code').text(), /int x = 1;/);
  assert.doesNotMatch(get('code').text(), /int y/);
  get('nextStep').onclick();
  assert.match(get('code').text(), /int y = 2;/);
  assert.equal(get('nextStep').disabled, true);
  get('previousStep').onclick();
  assert.doesNotMatch(get('code').text(), /int y/);
  assert.match(get('afterCode').textContent, /int x = 1;/);
});

test('code has its own tab origin and preserves mixed tabs and spaces', () => {
  const { get, context } = harness();
  const source = '<body>\n\t<h1>Hello</h1>\n    <div>안녕하세요.</div>\n\t\ttext\n</body>';
  context.input = JSON.stringify({ format: 'code-recorder', version: 2,
    initial: [{ fileId: 'a', path: 'hello.jsp', text: source }], events: [] });
  vm.runInContext('load(input, "indentation")', context);
  const lines = get('code').children;
  assert.ok(lines.every(line => line.children[0].className === 'line-number' && line.children[1].className === 'code-content'));
  assert.equal(lines.map(line => line.children[1].text()).join('\n'), source);
});

test('automatic Korean replay hides composition and commit flicker but keeps later deletion', () => {
  const { get, context, tick } = harness();
  const edits = [['', 'ㅇ'], ['ㅇ', '아'], ['아', '안'], ['안', ''], ['', '안'], ['안', '']];
  context.input = JSON.stringify({ format: 'code-recorder', version: 2,
    initial: [{ fileId: 'a', path: 'A.java', text: '' }],
    events: edits.map(([removedText, insertedText], i) => ({ seq: i + 1, type: 'edit',
      fileId: 'a', path: 'A.java', offset: 0, removedText, insertedText })) });
  vm.runInContext('load(input, "Korean")', context);
  get('autoMode').onclick(); get('restart').onclick(); get('play').onclick();
  tick(100);
  assert.equal(get('code').children[0].children[1].text(), '안');
  assert.equal(get('position').textContent, '5 / 6 순서');
  tick(100);
  assert.equal(get('code').children[0].children[1].text(), '', 'actual later deletion is preserved');
  get('progress').value = '2'; get('progress').oninput();
  assert.equal(get('code').children[0].children[1].text(), '안', 'seeking also lands on a completed syllable');
});

test('automatic replay applies a typed import at once and keeps normal code playback', () => {
  const { get, context, tick } = harness();
  const source = 'import java.util.List;\nclass A {}';
  context.input = JSON.stringify({ format: 'code-recorder', version: 2,
    initial: [{ fileId: 'a', path: 'A.java', text: '' }],
    events: [...source].map((insertedText, offset) => ({ seq: offset + 1, type: 'edit',
      fileId: 'a', path: 'A.java', offset, removedText: '', insertedText })) });
  vm.runInContext('load(input, "imports")', context);
  get('autoMode').onclick(); get('restart').onclick(); get('play').onclick();
  tick(100);
  assert.equal(get('code').children[0].children[1].text(), 'import java.util.List;');
  assert.doesNotMatch(get('code').text(), /class/);
  tick(100);
  assert.equal(get('code').children[1].children[1].text(), 'c');
});

test('optional file dividers wait for Continue; toggling off restores the default 2 second delay', () => {
  const { get, context, tick } = harness();
  context.input = JSON.stringify({ format: 'code-recorder', version: 2, initial: [
    { fileId: 'a', path: 'A.java', text: '' }, { fileId: 'b', path: 'B.java', text: '' }
  ], events: [
    { seq: 1, type: 'activate', fileId: 'b', path: 'B.java' },
    { seq: 2, type: 'edit', fileId: 'b', path: 'B.java', offset: 0, removedText: '', insertedText: 'hello' },
    { seq: 3, type: 'activate', fileId: 'a', path: 'A.java' }
  ] });
  vm.runInContext('load(input, "continue")', context);
  assert.equal(get('waitForContinue').checked, true);
  get('waitForContinue').checked = true; get('waitForContinue').onchange();
  get('play').onclick(); tick(100);
  assert.equal(get('continuePlayback').hidden, false);
  tick(60000);
  assert.equal(get('position').textContent, '0 / 3 순서');
  assert.equal(get('path').textContent, 'A.java');
  let prevented = false;
  const space = { code: 'Space', target: { tagName: 'BODY' }, preventDefault: () => { prevented = true; } };
  context.onkeydown({ ...space, target: { tagName: 'INPUT' } });
  assert.equal(get('position').textContent, '0 / 3 순서');
  context.onkeydown({ ...space, repeat: true });
  assert.equal(get('position').textContent, '0 / 3 순서');
  context.onkeydown(space);
  assert.equal(prevented, true);
  assert.equal(get('path').textContent, 'B.java');
  assert.equal(get('transition').hidden, true);
  get('continuePlayback').onclick(); // A repeated click cannot skip the next edit.
  assert.equal(get('position').textContent, '1 / 3 순서');
  tick(100); assert.match(get('code').text(), /hello/);
  tick(100); tick(60000);
  assert.equal(get('position').textContent, '2 / 3 순서');
  get('waitForContinue').checked = false; get('waitForContinue').onchange();
  assert.equal(get('continuePlayback').hidden, true);
  tick(1900); assert.equal(get('path').textContent, 'B.java');
  tick(100); assert.equal(get('path').textContent, 'A.java');
  get('restart').onclick();
  get('waitForContinue').checked = true; get('waitForContinue').onchange();
  get('play').onclick(); tick(100);
  get('stepMode').onclick();
  assert.equal(get('continuePlayback').hidden, true);
  tick(60000); assert.equal(get('position').textContent, '0 / 3 순서');
});

test('Continue immediately shows the next file, then waits 0–5 seconds before editing', () => {
  for (let seconds = 0; seconds <= 5; seconds++) {
    const { get, context, tick } = harness();
    context.input = JSON.stringify({ format: 'code-recorder', version: 2, initial: [
      { fileId: 'a', path: 'A.java', text: '' }, { fileId: 'b', path: 'B.java', text: '' }
    ], events: [
      { seq: 1, type: 'activate', fileId: 'b', path: 'B.java' },
      { seq: 2, type: 'edit', fileId: 'b', path: 'B.java', offset: 0, removedText: '', insertedText: 'hello' }
    ] });
    vm.runInContext('load(input, "delay")', context);
    get('continueDelay').value = String(seconds);
    get('play').onclick(); tick(100); tick(10000);
    assert.equal(get('path').textContent, 'A.java');
    get('continuePlayback').onclick();
    assert.equal(get('path').textContent, 'B.java');
    assert.equal(get('transition').hidden, true);
    assert.doesNotMatch(get('code').text(), /hello/);
    if (seconds > 0) {
      tick(seconds * 1000 - 1);
      assert.doesNotMatch(get('code').text(), /hello/);
      tick(1);
    } else tick(100);
    assert.match(get('code').text(), /hello/);
  }
});

test('implicit file switches also wait before their first edit and restart cancels the delay', () => {
  const { get, context, tick } = harness();
  context.input = JSON.stringify({ format: 'code-recorder', version: 2, initial: [
    { fileId: 'a', path: 'A.java', text: '' }, { fileId: 'b', path: 'B.java', text: '' }
  ], events: [{ seq: 1, type: 'edit', fileId: 'b', path: 'B.java', offset: 0, removedText: '', insertedText: 'hello' }] });
  vm.runInContext('load(input, "implicit")', context);
  get('continueDelay').value = '3'; get('play').onclick(); tick(100);
  get('continuePlayback').onclick();
  assert.equal(get('path').textContent, 'B.java');
  assert.doesNotMatch(get('code').text(), /hello/);
  tick(2999); assert.doesNotMatch(get('code').text(), /hello/);
  tick(1); assert.match(get('code').text(), /hello/);
  get('restart').onclick(); get('play').onclick(); tick(100);
  get('continuePlayback').onclick(); get('restart').onclick(); tick(5000);
  assert.equal(get('path').textContent, 'A.java');
  assert.equal(get('position').textContent, '0 / 1 순서');
});

test('viewer options persist across reloads and recording loads', () => {
  const storage = new Map();
  const first = harness(storage);
  first.get('follow').checked = false; first.get('follow').onchange();
  first.get('waitForContinue').checked = false; first.get('waitForContinue').onchange();
  first.get('continueDelay').value = '3'; first.get('continueDelay').onchange();
  first.get('speed').value = '2'; first.get('speed').onchange();
  first.get('transitionDuration').value = '4'; first.get('transitionDuration').onchange();
  first.get('stepMode').onclick();
  const second = harness(storage);
  assert.equal(second.get('follow').checked, false);
  assert.equal(second.get('waitForContinue').checked, false);
  assert.equal(second.get('continueDelay').value, '3');
  assert.equal(second.get('speed').value, '2');
  assert.equal(second.get('transitionDuration').value, '4');
  second.context.input = fs.readFileSync(path.join(__dirname, 'fixtures/navigation.coderec.json'), 'utf8');
  vm.runInContext('load(input, "first"); load(input, "second")', second.context);
  assert.equal(second.get('study').hidden, false);
  assert.equal(second.get('speed').value, '2');
  assert.deepEqual(Object.keys(JSON.parse([...storage.values()][0])).sort(),
    ['continueDelay', 'follow', 'speed', 'studyMode', 'transitionDuration', 'waitForContinue']);
});

test('invalid or unavailable local storage does not break the viewer', () => {
  for (const value of ['invalid JSON', '{"speed":"99","continueDelay":"-1","follow":"false"}']) {
    const { get } = harness(new Map([['code-recorder.viewer.settings.v1', value]]));
    assert.equal(get('speed').value, '1');
    assert.equal(get('follow').checked, true);
  }
  const blocked = { get() { throw Error('denied'); }, set() { throw Error('denied'); } };
  const { get } = harness(blocked);
  assert.doesNotThrow(() => get('speed').onchange());
});

test('timeline times track playback position, speed changes, seeking, and restart', () => {
  const { get, context, tick } = harness();
  context.input = JSON.stringify({ format: 'code-recorder', version: 2,
    initial: [{ fileId: 'a', path: 'A.java', text: '' }],
    events: Array.from({ length: 20 }, (_, i) => ({ seq: i + 1, type: 'edit', fileId: 'a',
      path: 'A.java', offset: i, removedText: '', insertedText: 'x' })) });
  vm.runInContext('load(input, "times")', context);
  assert.equal(get('elapsedTime').textContent, '진행 00:00');
  assert.equal(get('remainingTime').textContent, '남은 00:02');
  get('play').onclick();
  for (let i = 0; i < 10; i++) tick(100);
  assert.equal(get('elapsedTime').textContent, '진행 00:01');
  assert.equal(get('remainingTime').textContent, '남은 00:01');
  get('speed').value = '0.5'; get('speed').onchange();
  assert.equal(get('elapsedTime').textContent, '진행 00:02');
  assert.equal(get('remainingTime').textContent, '남은 00:02');
  get('progress').value = '20'; get('progress').oninput();
  assert.equal(get('elapsedTime').textContent, '진행 00:04');
  assert.equal(get('remainingTime').textContent, '남은 00:00');
  get('restart').onclick();
  assert.equal(get('elapsedTime').textContent, '진행 00:00');
});

test('automatic divider duration uses the selected 1–5 seconds independently of playback speed', () => {
  for (let seconds = 1; seconds <= 5; seconds++) {
    const { get, context, tick } = harness();
    context.input = JSON.stringify({ format: 'code-recorder', version: 2, initial: [
      { fileId: 'a', path: 'A.java', text: '' }, { fileId: 'b', path: 'B.java', text: '' }
    ], events: [{ seq: 1, type: 'activate', fileId: 'b', path: 'B.java' }] });
    vm.runInContext('load(input, "divider")', context);
    assert.equal(get('transitionDuration').disabled, true);
    get('waitForContinue').checked = false; get('waitForContinue').onchange();
    assert.equal(get('transitionDuration').disabled, false);
    assert.equal(get('continueDelay').disabled, true);
    get('transitionDuration').value = String(seconds); get('transitionDuration').onchange();
    get('speed').value = '4'; get('speed').onchange();
    get('play').onclick(); tick(100); tick(seconds * 1000 - 1);
    assert.equal(get('path').textContent, 'A.java');
    assert.equal(get('transition').hidden, false);
    tick(1);
    assert.equal(get('path').textContent, 'B.java');
    assert.equal(get('transition').hidden, true);
  }
});
